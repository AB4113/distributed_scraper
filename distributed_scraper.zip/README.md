# High-Throughput Distributed Web Scraper & Parser
### Developed by Abenezer Beyene

Production blueprint separating crawling (network-bound) from layout tree parsing (CPU-bound) utilizing distributed Celery queues and atomic Redis tracking sets.

## Installation
```bash
pip install -r requirements.txt
```

## Running the Architecture
1. **Launch Redis Broker:** Ensure Redis runs locally on port 6379.
2. **Network Workers:** `celery -A tasks worker -Q network_bound --concurrency=20 --loglevel=INFO`
3. **Parser Workers:** `celery -A tasks worker -Q cpu_bound --concurrency=4 --loglevel=INFO`
4. **Seed System Pipeline:** `python run.py`
