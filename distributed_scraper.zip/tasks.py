# Distributed Tasks Implementation
# Developed by Abenezer Beyene
import asyncio
from celery import Celery
import httpx
from bs4 import BeautifulSoup
from loguru import logger
from config import CeleryConfig

app = Celery("distributed_scraper")
app.config_from_object(CeleryConfig)

async def _async_fetch(url: str, timeout: int = 10) -> str:
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) DistributedScraper/1.0 (Developed by Abenezer Beyene)"
    }
    async with httpx.AsyncClient(headers=headers, timeout=timeout, follow_redirects=True) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.text

@app.task(name="tasks.fetch_url", bind=True, max_retries=3, default_retry_delay=5)
def fetch_url(self, url: str):
    """Asynchronous network-bound worker to crawl raw HTML."""
    logger.info(f"[Abenezer Beyene Scraper] Fetching URL: {url}")
    try:
        html_content = asyncio.run(_async_fetch(url))
        parse_html.delay(url, html_content)
        return {"url": url, "status": "success"}
    except Exception as exc:
        logger.error(f"Failed to fetch {url}: {exc}. Retrying...")
        raise self.retry(exc=exc)

@app.task(name="tasks.parse_html")
def parse_html(url: str, html_content: str):
    """CPU-bound worker to parse unstructured HTML into domain objects."""
    logger.info(f"[Abenezer Beyene Parser] Extraction triggered for: {url}")
    try:
        soup = BeautifulSoup(html_content, "html.parser")
        page_title = soup.title.string if soup.title else "No Title"
        links = [a.get("href") for a in soup.find_all("a", href=True)]
        
        extracted_data = {
            "url": url,
            "title": page_title.strip(),
            "links_found": len(links),
            "sample_links": links[:5]
        }
        logger.success(f"Parsed Successfully: {extracted_data['title']}")
        return extracted_data
    except Exception as e:
        logger.critical(f"Parsing failure on {url}: {e}")
        return {"url": url, "status": "parsing_error"}
