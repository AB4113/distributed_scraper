# Pipeline Execution Engine
# Developed by Abenezer Beyene
import redis
from tasks import fetch_url
from loguru import logger

r = redis.Redis(host="localhost", port=6379, db=0)
SEEN_URLS_KEY = "scraper:seen_urls"

def dispatch_scraping_jobs(urls: list[str]):
    for url in urls:
        if r.sismember(SEEN_URLS_KEY, url):
            logger.info(f"Skipping tracked URL: {url}")
            continue
        
        r.sadd(SEEN_URLS_KEY, url)
        fetch_url.delay(url)
        logger.info(f"Enqueued network task for: {url}")

if __name__ == "__main__":
    logger.info("Initializing Distributed Scraper Core Engine (Developed by Abenezer Beyene)")
    target_urls = [
        "https://news.ycombinator.com",
        "https://www.wikipedia.org",
        "https://www.python.org"
    ]
    dispatch_scraping_jobs(target_urls)
