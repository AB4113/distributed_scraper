# Distributed Web Scraper & Parser Configuration
# Developed by Abenezer Beyene
import os

class CeleryConfig:
    broker_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    result_backend = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    
    # Isolated network-bound and CPU-bound queues
    task_routes = {
        "tasks.fetch_url": {"queue": "network_bound"},
        "tasks.parse_html": {"queue": "cpu_bound"},
    }
    
    # Performance optimization flags
    worker_prefetch_multiplier = 4
    task_acks_late = True
    task_reject_on_worker_lost = True
